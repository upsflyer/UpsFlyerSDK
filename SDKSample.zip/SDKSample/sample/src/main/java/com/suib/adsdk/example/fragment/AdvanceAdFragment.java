package com.suib.adsdk.example.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.drawee.view.SimpleDraweeView;
import com.suib.adsdk.example.AdHolder;
import com.suib.adsdk.example.R;
import com.suib.adsdk.example.SampleApplication;
import com.suib.adsdk.example.config.Config;
import com.suib.adsdk.example.listener.MyCTAdEventListener;
import com.suib.sdk.SuibSDK;
import com.suib.sdk.base.NativeVo;

public class AdvanceAdFragment extends Fragment {

    private ViewGroup container;
    private ViewGroup adLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_advance_native, null);
        initView(view);
        return view;
    }

    private final static String TAG = "AdvanceAdTest";

    private void initView(View view) {
        container = (ViewGroup) view.findViewById(R.id.container);                         //媒体容器

        view.findViewById(R.id.load_ad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAd();
                Log.i(TAG, "loadAd");
            }
        });


        view.findViewById(R.id.load_for_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loadAdForCache();
                Log.i(TAG, "loadAdForCache");

            }
        });

        view.findViewById(R.id.show_from_cache).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getAdFromCacheAndShow();
                Log.i(TAG, "getAdFromCacheAndShow");

            }
        });

    }

    public void loadAd() {
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        SuibSDK.getNativeAd(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {

            @Override
            public void onReceiveAdSucceed(NativeVo result) {
                if (result == null) {
                    return;
                }
                showAd(result);
                Log.e(TAG, "onReceiveAdSucceed");
                super.onReceiveAdSucceed(result);
            }


            @Override
            public void onReceiveAdFailed(NativeVo result) {
                Log.e(TAG, "onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(NativeVo result) {
                Log.e(TAG, "onAdClicked");
                super.onAdClicked(result);
            }

        });

    }

    private void loadAdForCache() {
        SuibSDK.getNativeAdForCache(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {
            @Override
            public void onReceiveAdVoSucceed(NativeVo result) {
                if (result == null) {
                    return;
                }
                Log.e(TAG, "onReceiveAdVoSucceed");

                AdHolder.adNativeVO = result;
                super.onReceiveAdVoSucceed(result);

            }


            @Override
            public void onReceiveAdFailed(NativeVo result) {
                Log.e(TAG, "onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(NativeVo result) {
                Log.e(TAG, "onAdClicked");
                super.onAdClicked(result);
            }

        });
    }

    public void getAdFromCacheAndShow() {
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        NativeVo nativeVO = AdHolder.adNativeVO;

        if (nativeVO != null) {

            showAd(nativeVO);
        }

    }

    private void showAd(final NativeVo ctAdvanceNative) {

        SimpleDraweeView img = adLayout.findViewById(R.id.iv_img);
        SimpleDraweeView icon = adLayout.findViewById(R.id.iv_icon);
        TextView title = adLayout.findViewById(R.id.tv_title);
        TextView desc = adLayout.findViewById(R.id.tv_desc);
        TextView click = adLayout.findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = adLayout.findViewById(R.id.ad_choice_icon);

        img.setImageURI(Uri.parse(ctAdvanceNative.getImageUrl()));
        icon.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
        title.setText(ctAdvanceNative.getTitle());
        desc.setText(ctAdvanceNative.getDesc());
        click.setText(ctAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctAdvanceNative.getAdChoiceIconUrl());

        container.removeAllViews();

        //只是注册点击区域,调此处设置
        ctAdvanceNative.registerADClickArea(adLayout);
        container.addView(adLayout);

        ad_choice_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String linkUrl = ctAdvanceNative.getAdChoiceLinkUrl();
                if (TextUtils.isEmpty(linkUrl)) {
                    Toast.makeText(getContext(), "adChoiceLinkUrl is null", Toast.LENGTH_LONG).show();
                    return;
                }
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl));
                if (browserIntent.resolveActivity(getContext().getPackageManager()) != null) {
                    startActivity(browserIntent);
                }
            }
        });
    }

}