package com.suib.adsdk.example;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.support.multidex.MultiDex;
import android.util.Log;

import com.suib.adsdk.example.config.Config;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.stetho.Stetho;
import com.squareup.leakcanary.LeakCanary;
import com.suib.sdk.SuibSDK;

/*
 * Created by huangdong on 16/9/20.
 */
public class SampleApplication extends Application {

    public static Context context;
    public static boolean hasSplash = false;

    private int appCount = 0;

    public final static String TAG = "suib";


    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }


    @Override
    public void onCreate() {
        super.onCreate();

        if (BuildConfig.DEBUG) {
            if (LeakCanary.isInAnalyzerProcess(this)) {
                return;
            }
            LeakCanary.install(this); // TODO: 2016/12/28 检测内存泄露
        }
        context = this.getApplicationContext();

        SuibSDK.setSchema(this,true);
//      initialize the sdk
        SuibSDK.initialize(context, Config.slotIdReward);
//        SuibSDK.setIsChildDirected(context,true);

//      initialize the fresco for sample
        Fresco.initialize(context);
        Stetho.initializeWithDefaults(this);
        registerLifecycel();
    }


    public void registerLifecycel() {
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                Log.d(TAG, "onActivityCreated appCount=" + appCount);
            }

            @Override
            public void onActivityStarted(Activity activity) {
                appCount++;
                Log.d(TAG, "onActivityStarted appCount=" + appCount);
                notifySdk();
            }

            @Override
            public void onActivityResumed(Activity activity) {
                Log.d(TAG, "onActivityResumed appCount=" + appCount);
            }

            @Override
            public void onActivityPaused(Activity activity) {
                Log.d(TAG, "onActivityPaused appCount=" + appCount);
            }

            @Override
            public void onActivityStopped(Activity activity) {
                appCount--;
                Log.d(TAG, "onActivityStopped appCount=" + appCount);
                notifySdk();
            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {
                Log.d(TAG, "onActivityDestroyed appCount=" + appCount);

            }
        });
    }

    public void notifySdk() {
        if (getApplicationValue()) {
            SuibSDK.setBackgroundRun(this, false);
        } else {
            SuibSDK.setBackgroundRun(this, true);
        }
    }

    /**
     * 通过ActivityLifecycleCallbacks来批量统计Activity的生命周期，来做判断，此方法在API 14以上均有效，但是需要在Application中注册此回调接口
     * 必须：
     * 1. 自定义Application并且注册ActivityLifecycleCallbacks接口
     * 2. AndroidManifest.xml中更改默认的Application为自定义
     * 3. 当Application因为内存不足而被Kill掉时，这个方法仍然能正常使用。虽然全局变量的值会因此丢失，但是再次进入App时候会重新统计一次的
     *
     * @return
     */

    public boolean getApplicationValue() {
        return appCount > 0;
    }
}
