//package com.suib.adsdk.example.fragment;
//
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ListView;
//
//import com.suib.adsdk.example.R;
//import com.suib.adsdk.example.Utils;
//import com.suib.adsdk.example.adapter.NativeVideoListViewAdapter;
//import com.suib.adsdk.example.bean.News;
//import com.suib.adsdk.example.model.AdsModel;
//
//import java.util.List;
//
///**
// * Created by huangdong on 18/7/12.
// *
// */
//public class NativeVideoListFragment extends Fragment implements AdsModel.AdsModelListener {
//
//
//    public static final String TAG = "NativeVideoListFragment";
//    private View view;
//    private AdsModel adsModel;
//    private NativeVideoListViewAdapter nativeVideoListViewAdapter;
//
//    @Nullable
//    @Override
//    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        view = inflater.inflate(R.layout.fragment_native_video_list, null);
//        return view;
//    }
//
//    @Override
//    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
//        super.onActivityCreated(savedInstanceState);
//        ListView lv_native_video = view.findViewById(R.id.lv_native_video);
//        nativeVideoListViewAdapter = new NativeVideoListViewAdapter();
//        lv_native_video.setAdapter(nativeVideoListViewAdapter);
//
//
//        adsModel = AdsModel.getAdsModel();
//        adsModel.loadCommonData(16);
//        adsModel.loadVideoAds(3);
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//        adsModel.registerListener(this);
//        refleshUI();
//    }
//
//    @Override
//    public void onPause() {
//        super.onPause();
//        adsModel.removeListener(this);
//    }
//
//
//    @Override
//    public void onUpdate() {
//        refleshUI();
//    }
//
//    public void refleshUI() {
//        List<News> commonList = adsModel.getCommonList();
//        List<News> videoList = adsModel.getVideoList();
//
//        List<News> list = Utils.combineAdAndContent(commonList, videoList, 4);
//
//        nativeVideoListViewAdapter.setDate(list);
//    }
//
//}
//
//
