package com.suib.adsdk.example;

import com.suib.sdk.base.NativeVo;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static NativeVo adNativeVO = null;

}
