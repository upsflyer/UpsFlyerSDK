package com.suib.adsdk.example.config;

public class Config {

    public static String slotIdBanner = "67102232";
    public static String slotIdInterstitial = "46679067";
    public static String slotIdNative = "50597362";
    public static String slotIdAppWall = "85433048";
    public static String slotIdMutilAds = "50597362";
    public static String slotIdReward = "28255432";
    public static String slotIdNativeVideo = "16786846";


}
